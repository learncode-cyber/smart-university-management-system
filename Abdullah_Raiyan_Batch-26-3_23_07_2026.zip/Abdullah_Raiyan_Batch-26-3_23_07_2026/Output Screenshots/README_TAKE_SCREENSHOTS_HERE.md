এই ফোল্ডারে তোমাকে নিজে screenshot নিয়ে রাখতে হবে — আমি কখনো এই প্রজেক্ট আসলে "রান" করিনি
(sandbox-এ ইন্টারনেট না থাকায় docker/npm/pip install করতে পারিনি), তাই real output screenshot
আমার কাছে নেই। নিচের চেকলিস্ট অনুযায়ী screenshot নাও:

## Database
- [ ] pgAdmin/DBeaver-এ সব টেবিলের তালিকা (24+ tables)
- [ ] users, students, teachers টেবিলের ডেটা
- [ ] একটা migration history (alembic history / alembic current)

## Backend (Swagger docs — http://localhost:8000/docs)
- [ ] পুরো endpoint তালিকা (সব module: auth, users, exams, attendance, results, fees, schedule, notifications)
- [ ] একটা successful login response (/auth/login)
- [ ] একটা role-based 403 error (যেমন student হয়ে admin endpoint কল করা)

## Frontend (প্রতিটা screen থেকে অন্তত ১টা করে)
- [ ] Login page
- [ ] Dashboard (Student/Teacher/Admin/Parent — যতগুলো role দেখাতে পারো)
- [ ] Exam List + Exam Room (exam attempt করার সময়)
- [ ] Results page (transcript download সহ)
- [ ] Attendance page
- [ ] Fee Centre
- [ ] Timetable
- [ ] Admin: User Management, Result Approval, Fee Dashboard
- [ ] Teacher: Exam Builder, Grading, Attendance Marker
- [ ] Notifications panel

## Terminal
- [ ] `docker compose up --build` চলছে এমন একটা screenshot
- [ ] `pytest tests/` পাস হওয়ার screenshot

স্ক্রিনশট নেওয়ার আগে অ্যাপটা রান করতে হবে:
    docker compose up --build
তারপর http://localhost:5173 (frontend) আর http://localhost:8000/docs (backend) থেকে screenshot নাও।
