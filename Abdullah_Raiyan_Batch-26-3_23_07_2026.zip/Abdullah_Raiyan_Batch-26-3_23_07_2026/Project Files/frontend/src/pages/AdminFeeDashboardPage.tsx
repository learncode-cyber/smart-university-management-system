import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useToast } from "@/contexts/ToastContext";
import { useFeeDashboardSummary, useOverdueInvoices, useSendOverdueNotices } from "@/lib/queries";
import { extractApiErrorMessage } from "@/lib/apiClient";

export function AdminFeeDashboardPage() {
  const summary = useFeeDashboardSummary();
  const overdue = useOverdueInvoices();
  const sendNotices = useSendOverdueNotices();
  const { showToast } = useToast();
  const [hasSentThisSession, setHasSentThisSession] = useState(false);

  async function handleSendNotices() {
    if (!window.confirm(`Send an overdue reminder to all ${overdue.data?.length ?? 0} affected students?`)) return;
    try {
      const result = await sendNotices.mutateAsync();
      showToast(result.message, "success");
      setHasSentThisSession(true);
    } catch (err) {
      showToast(extractApiErrorMessage(err), "error");
    }
  }

  return (
    <AppLayout title="Fee Dashboard">
      {summary.isLoading && <p className="text-slate text-sm mb-6">Loading revenue summary...</p>}
      {!summary.isLoading && summary.isError && (
        <p role="alert" className="text-brick text-sm mb-6">Couldn't load the revenue summary.</p>
      )}
      {!summary.isLoading && summary.data && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="border border-slate/20 rounded bg-white p-5">
            <p className="text-slate text-xs mb-1">Total Invoiced</p>
            <p className="font-display text-2xl">{summary.data.total_invoiced.toFixed(2)}</p>
          </div>
          <div className="border border-slate/20 rounded bg-white p-5">
            <p className="text-slate text-xs mb-1">Total Collected</p>
            <p className="font-display text-2xl text-field-green">{summary.data.total_collected.toFixed(2)}</p>
          </div>
          <div className="border border-slate/20 rounded bg-white p-5">
            <p className="text-slate text-xs mb-1">Outstanding</p>
            <p className="font-display text-2xl text-brass">{summary.data.total_outstanding.toFixed(2)}</p>
          </div>
          <div className="border border-slate/20 rounded bg-white p-5">
            <p className="text-slate text-xs mb-1">Overdue Invoices</p>
            <p className="font-display text-2xl text-brick">{summary.data.overdue_count}</p>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-lg">Overdue Accounts</h2>
        <button
          onClick={handleSendNotices}
          disabled={sendNotices.isPending || (overdue.data?.length ?? 0) === 0}
          className="bg-brick text-white rounded px-4 py-1.5 text-sm font-medium hover:bg-brick/90 transition-colors disabled:opacity-40"
        >
          {sendNotices.isPending ? "Sending..." : "Send Overdue Notices"}
        </button>
      </div>

      {hasSentThisSession && (
        <p className="text-field-green text-xs mb-3">
          Notices sent this session — students will see them in their Notifications panel.
        </p>
      )}

      {overdue.isLoading && <p className="text-slate text-sm">Loading overdue accounts...</p>}
      {!overdue.isLoading && overdue.isError && (
        <p role="alert" className="text-brick text-sm">Couldn't load overdue accounts.</p>
      )}
      {!overdue.isLoading && !overdue.isError && (overdue.data?.length ?? 0) === 0 && (
        <div className="border border-slate/20 rounded bg-white p-8 text-center">
          <p className="text-slate">No overdue accounts right now.</p>
        </div>
      )}
      {!overdue.isLoading && !overdue.isError && (overdue.data?.length ?? 0) > 0 && (
        <div className="border border-slate/20 rounded bg-white overflow-hidden">
          <table className="ledger-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Due</th>
                <th>Paid</th>
                <th>Outstanding</th>
                <th>Due Date</th>
              </tr>
            </thead>
            <tbody>
              {overdue.data!.map((inv) => (
                <tr key={inv.id}>
                  <td className="font-medium">{inv.student_name}</td>
                  <td className="font-mono">{inv.amount_due.toFixed(2)}</td>
                  <td className="font-mono">{inv.amount_paid.toFixed(2)}</td>
                  <td className="font-mono text-brick">{inv.outstanding.toFixed(2)}</td>
                  <td className="font-mono text-xs">{inv.due_date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppLayout>
  );
}
