import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Dev server proxies /api to the FastAPI backend so the frontend never
// needs CORS configured for local development. Target is configurable via
// VITE_BACKEND_URL so the same config works for `npm run dev` locally
// (defaults to localhost:8000) and inside Docker Compose (set to
// http://backend:8000, the service name — see docker-compose.yml).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    proxy: {
      "/api": {
        target: process.env.VITE_BACKEND_URL || "http://localhost:8000",
        changeOrigin: true,
      },
    },
  },
});
