# University Management System

Final project — ICT Bangladesh, AI-Powered Software Engineering Batch 26/3.

Backend: FastAPI + PostgreSQL + SQLAlchemy 2.0 + Alembic
Frontend: React 18 + TypeScript + TailwindCSS + React Query

---

## Quick start (Docker — recommended)

```bash
docker compose up --build
```

This starts Postgres, runs migrations, seeds the first admin account, and starts both
the API (`:8000`) and the web app (`:5173`). First run takes a minute or two.

- Web app: http://localhost:5173
- API docs (Swagger): http://localhost:8000/docs
- **Default admin login** (change immediately after first login):
  `admin@university.edu` / `ChangeMe123!`

To stop: `docker compose down`. To wipe the database and start fresh: `docker compose down -v`.

---

## Manual setup (without Docker)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# create a Postgres database matching backend/.env.example, or update DATABASE_URL
cp .env.example .env

alembic upgrade head
python -m scripts.seed          # creates the first admin account — see below
uvicorn app.main:app --reload
```

API now runs at http://localhost:8000 (docs at `/docs`).

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Web app runs at http://localhost:5173 and proxies `/api` to `http://localhost:8000`
(see `vite.config.ts`).

---

## Why a seed script? (bootstrap gap, flagged during the build)

Every account-creation endpoint (`POST /users/students`, `POST /users/teachers`)
requires an already-logged-in Admin. On a freshly migrated, empty database there is no
admin to log in as — the system would otherwise be unbootable. `backend/scripts/seed.py`
creates exactly one university, one department, and one admin account (see credentials
above). It's a no-op if a university already exists, so it's safe to run more than once.

After logging in as the seeded admin, use **Admin → User Management** to create real
department/course data and onboard actual students/teachers.

---

## Environment variables

See `backend/.env.example` for the full list. The only one that matters beyond local
dev is `JWT_SECRET_KEY` — generate a real one for anything other than a local demo:

```bash
python -c "import secrets; print(secrets.token_urlsafe(64))"
```

---

## Running backend tests

```bash
cd backend
pip install pytest
pytest tests/
```

Covers the pure business-logic functions called out in the brief: attendance
percentage, GPA calculation, fee/invoice status, marks aggregation, and schedule
conflict detection — all unit-tested independent of the database.

---

## Project structure

```
backend/
  app/
    api/v1/        # routers — thin, parse request → call service → shape response
    services/       # business logic (incl. pure, unit-tested functions)
    models/          # SQLAlchemy ORM models
    schemas/          # Pydantic request/response schemas
    core/              # config, security, error shapes, rate limiting
  alembic/             # migrations
  scripts/seed.py       # bootstrap script (see above)
  tests/                # pytest unit tests for pure functions

frontend/
  src/
    pages/          # one file per screen (Section 7 of the proposal)
    components/      # layout shell, dashboard widgets, shared Modal
    contexts/          # auth, toast
    lib/                # typed API client, React Query hooks
    types/                # shared TypeScript types mirroring backend schemas
```

---

## Flagged deviations from the original proposal

The proposal (Section 6, REST API spec) omitted a few things needed to actually run
the system end-to-end. Each is flagged in code comments at the point it was added;
summary here for the video walkthrough:

| Addition | Why |
|---|---|
| Academic Structure module (`/academic/*`) | Exams/attendance/results/schedule all need a `course_section_id`, which needs departments/courses/sections to exist first |
| Parent access to attendance/results/schedule `/me` endpoints | Section 5 promises this for Parent; Section 6 only listed Student |
| Student access to `/fees/payments/{id}` | Section 3 promises "view full payment history" for Student; Section 6 listed Admin/Parent only |
| `GET /results/pending` | No way to list results awaiting approval otherwise — the approval workflow was unusable without it |
| `GET/POST /fees/dashboard-summary`, `/fees/overdue/send-notices` | "Real-time revenue view" and "bulk notice sender" were described for the Admin Fee Dashboard screen but had no backing endpoints |
| `GET /academic/course-sections/{id}/students` (class roster) | Needed for the Teacher Attendance Marker screen — no way to know who's enrolled otherwise |
| Entire Notifications module (`/notifications/*`) | Never defined in Section 6 at all, despite Section 3/7 requiring a working notification feed, and other modules already creating `Notification` rows |
| `backend/scripts/seed.py` | Bootstrap gap — see above |

---

## Video presentation checklist

Mapped to the grading rubric in the proposal (Section 2).

**API completeness (30 marks)**
- [ ] Show `/docs` (Swagger) — walk through each module's endpoints
- [ ] Demonstrate JWT auth: login, an authenticated request, refresh, logout
- [ ] Demonstrate RBAC: same endpoint, two roles, different results (e.g. student vs teacher hitting `/exams`)
- [ ] Show a request that gets rejected by validation (Pydantic) and one rejected by a business rule (e.g. submitting an exam after its deadline)

**UI completeness + role-based access (30 marks)**
- [ ] Walk through all 4 roles logging in and landing on their own dashboard
- [ ] Student: sit an exam end-to-end (MCQ auto-grades instantly), check Results/Attendance/Fees
- [ ] Teacher: build an exam, mark attendance, grade a written answer
- [ ] Admin: approve a result, view the fee dashboard, send overdue notices
- [ ] Parent: show the same data scoped to their linked child
- [ ] Show a loading state, an error state, and an empty state (resize the browser to show responsive layout too)

**Database design (15 marks)**
- [ ] Show the ER structure — highlight `university_id` on every tenant table (multi-tenancy readiness) and the RESTRICT foreign keys that protect historical records from deletion
- [ ] Explain one non-obvious design decision out loud (e.g. why `exam_answers` holds grading data instead of a separate `exam_grades` table)

**Code quality, documentation, deployment (5 marks)**
- [ ] `docker compose up --build` running live, from a clean checkout
- [ ] Show the pure, unit-tested functions (`services/grading.py`, `gpa.py`, `attendance_calc.py`, `fee_calc.py`, `schedule_calc.py`) and run `pytest`
- [ ] Mention the flagged-deviations table above — shows you understood the spec well enough to know where it was incomplete, not just where it was explicit
